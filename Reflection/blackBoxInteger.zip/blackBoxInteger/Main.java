package blackBoxInteger;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchFieldException {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        Class<BlackBoxInt> clazz = BlackBoxInt.class;

        //взимаме си първо конструктора от този клас
        Constructor<BlackBoxInt> constructor = clazz.getDeclaredConstructor();
        // сетваме го с access, за да може той да бъде достъпен
        constructor.setAccessible(true);

        //създаваме обект от този клас чрез конструктора
        BlackBoxInt blackBoxInt = constructor.newInstance();

        Field innerValue = clazz.getDeclaredField("innerValue");

        //взимаме всички методи
        List<Method> methods = Arrays.asList(clazz.getDeclaredMethods());

        while(!input.equals("END")) {
            String commandName = input.split("_")[0];
            int number = Integer.parseInt(input.split("_")[1]);
              //add_{number}
              //subtract_{number}
              //divide_{number}
             //multiply_{number}
             //rightShift_{number}
             //leftShift_{number}

            switch (commandName) {
                case "add":
                    executeMethod(blackBoxInt, innerValue, number, "add", methods);
                    break;
                case "subtract":
                    executeMethod(blackBoxInt, innerValue, number, "subtract", methods);
                    break;
                case "divide":
                    executeMethod(blackBoxInt, innerValue, number, "divide", methods);
                    break;
                case "multiply":
                    executeMethod(blackBoxInt, innerValue, number, "multiply", methods);
                    break;
                case "rightShift":
                    executeMethod(blackBoxInt, innerValue, number, "rightShift", methods);
                    break;
                case "leftShift":
                    executeMethod(blackBoxInt, innerValue, number, "leftShift", methods);
                    break;
            }

            input = scanner.nextLine();
        }

    }

    private static void executeMethod(BlackBoxInt blackBoxInt, Field innerValue, int number, String command, List<Method> methods) throws IllegalAccessException, InvocationTargetException {
        Method currentMethod = null;
        for (Method method : methods) {
            if(method.getName().equals(command)) {
                currentMethod = method;
                break;
            }
        }
        currentMethod.setAccessible(true);
        currentMethod.invoke(blackBoxInt, number); //изпълняваме метода
        innerValue.setAccessible(true);
        System.out.println(innerValue.get(blackBoxInt));

    }
}
