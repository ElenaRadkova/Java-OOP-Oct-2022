package pizzaCalories;

public class Topping {
    private String toppingType;
    private double weight;

    public Topping(String toppingType, double weight) {
        setToppingType(toppingType);
        setWeight(weight);
    }

    private void setToppingType(String toppingType) {
        switch (toppingType) {
            case "Meat":
            case "Veggies":
            case "Cheese":
            case "Sauce":
                this.toppingType = toppingType;
                break;
            default:
                String message = "Cannot place " + toppingType + " on top of your pizza.";
                throw new IllegalArgumentException(message);
        }
    }

    private void setWeight(double weight) {
        if (weight >= 0 && weight <= 50) {
            this.weight = weight;
        } else {
            String message = toppingType + " weight should be in the range [1..50].";
            throw new IllegalArgumentException(message);
        }
    }

    public double calculateCalories() {
        // 2 * weight * toppingModifier
        double toppingModifier = 0; // коефициент на топинга
        if (this.toppingType.equals("Meat")) {
            toppingModifier = 1.2;
        } else if (this.toppingType.equals("Veggies")) {
            toppingModifier = 0.8;
        } else if (this.toppingType.equals("Cheese")) {
            toppingModifier = 1.1;
        } else if (this.toppingType.equals("Sauce")) {
            toppingModifier = 0.9;
        }
        return 2 * weight * toppingModifier;
    }
}
