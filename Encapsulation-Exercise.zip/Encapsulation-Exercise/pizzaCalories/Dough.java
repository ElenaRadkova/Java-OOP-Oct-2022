package pizzaCalories;

public class Dough {
    private String flourType; //White and Wholegrain
    private String bakingTechnique; //Crispy, Chewy, Homemade
    private double weight; // 1-200

    public Dough(String flourType, String bakingTechnique, double weight) {
        setFlourType(flourType);
        setBakingTechnique(bakingTechnique);
        setWeight(weight);
    }

    private void setFlourType(String flourType) {
        if (flourType.equals("White") || flourType.equals("Wholegrain")) {
            this.flourType = flourType;
        } else {
            throw new IllegalArgumentException("Invalid type of dough.");
        }
    }

    private void setBakingTechnique(String bakingTechnique) {
        switch (bakingTechnique) {
            case "Crispy":
            case "Chewy":
            case "Homemade":
                this.bakingTechnique = bakingTechnique;
                break;
            default:
                throw new IllegalArgumentException("Invalid type of dough.");
        }
    }

    private void setWeight(double weight) {
        if(weight >= 1 && weight <= 200) {
            this.weight = weight;
        } else {
            throw new IllegalArgumentException("Dough weight could be in the range [1..200].");
        }
    }

    public double calculateCalories() {
        // 2 * weight * flourModifier * techniqueModifier * toppingModifier
       double flourModifier = 0; // коефициент на типа брашно
        double techniqueModifier = 0; // коефициент на техниката на печене
        if(this.flourType.equals("White")) {
            flourModifier = 1.5;
        } else if (this.flourType.equals("Wholegrain")) {
            flourModifier = 1.0;
        }
        if ("Crispy".equals(bakingTechnique)) {
            techniqueModifier = 0.9;
        } else if ("Chewy".equals(bakingTechnique)) {
            techniqueModifier = 1.1;
        } else if ("Homemade".equals(bakingTechnique)) {
            techniqueModifier = 1.0;
        }
        return  2 * this.weight * flourModifier * techniqueModifier;
    }
}
