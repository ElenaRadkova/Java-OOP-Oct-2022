# Encapsulation-Exercise
This is repo with execises of Java OOP in SoftUni  October 2022
